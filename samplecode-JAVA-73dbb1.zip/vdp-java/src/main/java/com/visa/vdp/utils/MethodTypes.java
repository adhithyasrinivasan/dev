package com.visa.vdp.utils;

public enum MethodTypes {
    GET, POST, PUT, DELETE
}
